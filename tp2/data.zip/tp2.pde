int pantalla = 0;
float yTexto = 480;
PFont fuente;
PImage img1, img2, img3, img4;
int tiempoInicio = 0;

void setup() {
  size(640, 480);
  frameRate(30);

  fuente = createFont("Arial Bold", 28);
  textFont(fuente);
  textAlign(CENTER);

  // imagenes
  img1 = loadImage("TP1.jpg");
  img2 = loadImage("TP2.jpg");
  img3 = loadImage("TP3.jpg");
  img4 = loadImage("TP4.jpg");

  tiempoInicio = frameCount;  // frame en el que empieza 
}

void draw() {
  background(0);

  if (pantalla == 0) {
    mostrarPantalla(img1, "¡Bienvenido a la aventura!");
  } else if (pantalla == 1) {
    mostrarPantalla(img2, "Explorá mundos increíbles");
  } else if (pantalla == 2) {
    mostrarPantalla(img3, "¡Desafíos y diversión asegurada!");
  } else if (pantalla == 3) {
    mostrarFinal();
    return;
  }

  // avanza de pantalla cada 180 frames (6 segundos a 30 fps)
  if (frameCount - tiempoInicio > 180 && pantalla < 3) {
    pantalla++;
    tiempoInicio = frameCount;
    yTexto = 480;
  }
}

void mostrarPantalla(PImage fondo, String texto) {
  image(fondo, 0, 0, width, height);

  float alpha = (sin(frameCount / 10.0) + 1) * 127;  // animación con opacidad
  fill(255, 255, 0, alpha);
  textSize(28);
  text(texto, width / 2, yTexto);
  yTexto -= 0.5;
}

void mostrarFinal() {
  image(img4, 0, 0, width, height);

  fill(255, 165, 0);
  ellipse(width / 2, 400, 150, 150);

  fill(0);
  textSize(20);
  text("Reiniciar", width / 2, 400);
}

void mousePressed() {
  // if estamos en la pantalla final -> clic en botón -> reiniciar
  if (pantalla == 3 && dist(mouseX, mouseY, width / 2, 400) < 75) {
    pantalla = 0;
    tiempoInicio = frameCount;
    yTexto = 480;
  }
}
